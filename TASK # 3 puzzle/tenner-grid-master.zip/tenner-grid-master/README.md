# tenner-grid
Artificial intelligence algorithms for solving Tenner Grid puzzles. Implementation of constraint propagators and constraint satisfaction problem models.
