import hashlib

server_seed = "5f692b19314055dc74cd103741e81a72495d5df25ab56ee78848303d58e9de6d"
server_seed_hash = "d9e6c6864fc2ac0660f5d5029ca12fbd53ae231a2da850d4ad65a884fe886eb1"

hash_object = hashlib.sha256()

hash_object.update(server_seed.encode())

server_seed_hash_copy = hash_object.hexdigest()
print(server_seed_hash_copy)

encrypted_server_seed = hashlib.sha256(server_seed.encode()).hexdigest()

if encrypted_server_seed == server_seed_hash:
    print("Server seed and server seed hash match!")
else:
    print("Server seed and server seed hash do not match.")


