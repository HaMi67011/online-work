/*****************************************************************//**
 * \file   Submarine.hpp
 * \brief  
 * 
 * \author pablo
 * \date   January 2023
 *********************************************************************/
#ifndef SUBMARINE_HPP
#define SUBMARINE_HPP

#include "Ship.hpp"

class Submarine : public Ship
{
public:
    Submarine();
};

#endif // SUBMARINE_HPP