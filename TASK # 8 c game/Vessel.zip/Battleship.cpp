#include "Battleship.hpp"

Battleship::Battleship()
{
    name = "Battleship";
    size = 4;
    symbol = 'B';
    orientation = 'V';
    x = 0;
    y = 0;
}