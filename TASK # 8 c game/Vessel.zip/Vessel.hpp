#ifndef VESSEL_HPP
#define VESSEL_HPP

#include "Ship.hpp"

class Vessel : public Ship
{
public:
    Vessel();
};

#endif // VESSEL_HPP