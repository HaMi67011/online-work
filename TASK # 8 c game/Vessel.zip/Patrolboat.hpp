/*****************************************************************//**
 * \file   PatrolBoat.hpp (patrullero)
 * \brief  
 * 
 * \author pablo
 * \date   January 2023
 *********************************************************************/
#ifndef PATROLBOAT_HPP
#define PATROLBOAT_HPP

#include "Ship.hpp"
class PatrolBoat : public Ship
{
public:
	PatrolBoat();
};

#endif // PATROLBOAT_HPP