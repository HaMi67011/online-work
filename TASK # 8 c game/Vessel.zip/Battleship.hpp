#ifndef BATTLESHIP_HPP
#define BATTLESHIP_HPP

#include "Ship.hpp"

class Battleship : public Ship
{
public:
    Battleship();
};

#endif // BATTLESHIP_HPP
