#include "Carrier.hpp"

Carrier::Carrier()
{
    name = "Carrier";
    size = 5;
    symbol = 'C';
    orientation = 'V';
    x = 0;
    y = 0;
}
