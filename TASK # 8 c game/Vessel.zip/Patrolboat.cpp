#include "Patrolboat.hpp"

PatrolBoat::PatrolBoat()
{
    name = "PatrolBoat";
    size = 2;
    symbol = 'P';
    orientation = 'V';
    x = 0;
    y = 0;
}