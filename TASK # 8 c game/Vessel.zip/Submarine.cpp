#include "Submarine.hpp"

Submarine::Submarine()
{
    name = "Submarine";
    size = 3;
    symbol = 'S';
    orientation = 'V';
    x = 0;
    y = 0;
}