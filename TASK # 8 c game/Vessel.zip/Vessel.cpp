#include "Vessel.hpp"

Vessel::Vessel()
{
    name = "Embarcação";
    size = 1;
    symbol = 'V';
    orientation = 'V';
    x = 0;
    y = 0;
}