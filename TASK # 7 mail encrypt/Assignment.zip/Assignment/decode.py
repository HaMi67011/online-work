def decode(cmFname: str, receivers: list = None, senders: list = None) -> tuple:
    """Decode (decrypt and/or verify) the message found in the file named `cmFname`
    for the specified `receivers` and `senders`.
    The `receivers` and `senders` lists contain names of users.
    Returns a tuple (msg, receiversState, sendersState, hashState, secretState).
    """
    # Initialization
    cm = HvaCryptoMail()
    cm.load(cmFname, gVbs)

    if receivers is None:
        receivers = list(cm.rcvs.keys())
    if senders is None:
        senders = list(cm.snds.keys())
    if gDbg:
        print(f"DEBUG: receivers={receivers} senders={senders}")

    msg = None
    receiversState = {}
    sendersState = {}
    hashState = None
    secretState = None

    # Set secretState to True if no secrets are revealed, otherwise False
    secretState = True if not cm.hasMode('crypted') else False

    if cm.hasMode('crypted'):
        if gVbs:
            print('Verbose: crypted')
        # Decrypt the message for receivers or senders
        # and update sendersState or receiversState
        for receiver in receivers:
            if receiver in cm.rcvs:
                receiver_private_key = get_private_key(receiver)
                decrypted_message = cm.decrypt(receiver_private_key)
                receiversState[receiver] = decrypted_message

        for sender in senders:
            if sender in cm.snds:
                sender_public_key = get_public_key(sender)
                decrypted_message = cm.decrypt(sender_public_key)
                sendersState[sender] = decrypted_message

    if cm.hasMode('hashed'):
        if gVbs:
            print('Verbose: hashed')
        # Verify the message for receivers or senders
        # and update sendersState or receiversState
        for receiver in receivers:
            if receiver in cm.rcvs:
                hash_value = cm.verify(receiver)
                receiversState[receiver] = hash_value

        for sender in senders:
            if sender in cm.snds:
                hash_value = cm.verify(sender)
                sendersState[sender] = hash_value

    # Retrieve the hash state
    if cm.hasMode('hashed'):
        hashState = cm.hsh

    # Convert bytes to str
    msg = cm.msg.decode('utf-8') if cm.msg else None

    return msg, receiversState, sendersState, hashState, secretState
